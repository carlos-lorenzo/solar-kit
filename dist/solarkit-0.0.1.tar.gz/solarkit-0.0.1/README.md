# solar-kit
Tool to visualise and perform calculation on a solar system. Part of BPhO Computational challenge 2023 submission.
